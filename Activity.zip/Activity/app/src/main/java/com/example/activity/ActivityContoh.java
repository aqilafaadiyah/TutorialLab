package com.example.activity;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class ActivityContoh extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_satu);
    }
}
